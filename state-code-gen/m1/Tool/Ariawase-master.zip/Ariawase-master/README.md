﻿# What is Ariawase?

Ariawase is an open source VBA library.

## Quick Start

Run `build.bat`, you'll get office macro-enabled file in bin directory.

## Articles

Coming soon! Please check back.

## License

This software is released under the MIT License, see [LICENSE.txt](./LICENSE.txt).
